//
//  Favourites.swift
//  MyTravelHelper
//
//  Created by Arvinth on 27/08/22.
//  Copyright © 2022 Sample. All rights reserved.
//

import Foundation

class Favourites {
    
    
    let userDefaults = UserDefaults.standard
    
    func getFavouritesArray() -> [String] {
        return userDefaults.stringArray(forKey: "favourite") ?? []
    }
    
    func addFavourites(station: String) {
        var favouriteArray = getFavouritesArray()
        if !favouriteArray.contains(station) {
            favouriteArray.append(station)
            userDefaults.set(favouriteArray, forKey: "favourite")
        }
    }
    
}
